package com.ssafy.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.board.model.Board;
import com.ssafy.board.model.service.BoardService;

@RestController
@RequestMapping("/bs")
public class BoardRestController {
	
	@Autowired
	private BoardService boardService;
	
	@GetMapping("/list")
	public ResponseEntity<?> listArticle() {
		try {
			return new ResponseEntity<List<Board>>(boardService.listArticle(), HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return exceptionHandling(e);
		}
	}
	
//	@PostMapping("/write")
//	public ResponseEntity<?> writeArticle() {
//		
//	}
	
	@PutMapping("/update/{num}")
	public ResponseEntity<?> updateArticle(@PathVariable("num") int num) {
		try {
			return new ResponseEntity<Board>(boardService.updateArticle(num), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return exceptionHandling(e);
		}
	}
	
//	@DeleteMapping("/delete")
//	public ResponseEntity<?> deleteArticle(){
//		
//	}
//	
	@GetMapping("/list/{num}")
	public ResponseEntity<?> readArticle(@PathVariable("num") int num){
		try {
			return new ResponseEntity<Board>(boardService.readArticle(num), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return exceptionHandling(e);
		}
	}
	
	private ResponseEntity<String> exceptionHandling(Exception e) {
		return new ResponseEntity<String>("Error : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
