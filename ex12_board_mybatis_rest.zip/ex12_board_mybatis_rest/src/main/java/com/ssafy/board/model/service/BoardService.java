package com.ssafy.board.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.model.Board;
import com.ssafy.board.model.dao.BoardDao;
@Service
public class BoardService {
	
	@Autowired
	private BoardDao boardDao;
	
//	public void writeArticle(Board board) {
//		boardDao.writeArticle(board);
//	}

	public List<Board> listArticle() throws Exception{
		// TODO Auto-generated method stub
		return boardDao.listArticle();
	}

	public Board readArticle(int num) throws Exception{
		// TODO Auto-generated method stub
		return boardDao.readArticle(num);
	}

	public Board updateArticle(int num) throws Exception {
		// TODO Auto-generated method stub
		return boardDao.updateArticle(num);
	}

}
