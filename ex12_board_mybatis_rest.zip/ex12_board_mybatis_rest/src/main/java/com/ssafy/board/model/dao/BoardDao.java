package com.ssafy.board.model.dao;

import java.util.List;

import com.ssafy.board.model.Board;

public interface BoardDao {

	//void writeArticle(Board board);

	List<Board> listArticle() throws Exception;

	Board readArticle(int num) throws Exception;

	Board updateArticle(int num) throws Exception;
}
