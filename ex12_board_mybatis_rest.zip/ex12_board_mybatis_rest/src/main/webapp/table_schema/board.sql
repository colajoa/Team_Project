use ssafyweb;

create table board2(
	num       int        primary key auto_increment,
	writer    varchar(12)  not null,
	title     varchar(50)  not null,
	content   varchar(4000),
	pwd       varchar(12)  not null,
	hit       int       not null ,
	regdate   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

select * from board2;
update board2 set hit=0;

insert into board2(writer, title,content,pwd) values(1,1,1,1);
delete from board2 where writer = 1;