  const splitedURL = location.href.split('/');
	// URL에서 파싱한 현재 게시글의 ID
	const boardId = splitedURL[splitedURL.length - 1];
	
	const realPassword = document.querySelector("#board-password");

window.onload = function(){
  modifyArticle(boardId);
}

  function modifyArticle(boardId){
    fetch(`../bs/list/${boardId}`)
  .then((response) => response.json())
  .then((data)=> modify(data));
  }

  function modify(board) {
    document.querySelector(`#board-number`).innerText = board.num;
    document.querySelector(`#board-writer`).value = board.writer;
    document.querySelector(`#board-hit`).innerText = board.hit;
    document.querySelector(`#board-title`).value = board.title;
    document.querySelector(`#board-content`).value = board.content;
  }

function update(board){
    let writer = document.querySelector(`#board-writer`).value;
    let title = document.querySelector(`#board-title`).value;
    let content = document.querySelector(`#board-content`).value;

    let updateInfo = {
      writer : writer,
      title : title,
      content : content
    };

    let config = {
      method : "PUT",
      header : {"Content-Type": "application/json"},
      body : JSON.stringify(updateInfo)
    };

    fetch(`../board/list/${boardId}`, config)
    // .then((response) => response.json())
  }


  
  function read() {
    location.href = "/board/list/"+ boardId;
  }