const splitedURL = location.href.split('/');
	// URL에서 파싱한 현재 게시글의 ID
	const boardId = splitedURL[splitedURL.length - 1];
	
	let realPassword;

window.onload = function(){
  
  readArticle(boardId);
}

const readArticle = function(boardId){
  fetch(`../bs/list/${boardId}`)
  .then((response) => response.json())
  .then((data)=>read(data));
}

const read = function(board) {
  document.querySelector(`#board-number`).innerText = board.num;
  document.querySelector(`#board-writer`).innerText = board.writer;
  document.querySelector(`#board-hit`).innerText = board.hit;
  document.querySelector(`#board-title`).innerText = board.title;
  document.querySelector(`#board-content`).innerText = board.content;
}

function modify() {
  location.href = "/board/update/"+ boardId;
}


