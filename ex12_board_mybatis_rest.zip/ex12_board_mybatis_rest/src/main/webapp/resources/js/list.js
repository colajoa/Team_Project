window.onload = function(){
  listArticle();
}

const listArticle = function(){
  fetch(`./bs/list`)
  .then((response) => response.json())
  .then((data)=>makeList(data));
}

const makeList = function(boards) {
  const list = document.querySelector("#articleList");
  let str = "";
  boards.forEach(board => {
    str += `
    <tr>
      <td>${board.num}</td>
      <td><a href="list/${board.num}">${board.title}</a></td>
      <td>${board.writer}</td>
      <td>${board.regdate}</td>
      <td>${board.hit}</td>
    </tr>
    `

    list.innerHTML = str;
  });
}